# Guía técnica para Christian — Chomby

## 1. Qué tipo de proyecto es

Es una aplicación web full stack. El frontend genera HTML, pero los archivos fuente
principales son `.tsx`, `.ts` y `.css`. No es una aplicación PHP ni un único HTML.

| Capa | Implementación incluida |
|---|---|
| Interfaz | React 19.2.6, TypeScript, componentes Shadcn y CSS |
| Enrutamiento | App Router compatible con Next.js 16.2.6 mediante Vinext 0.0.50 |
| Compilación | Vite 8.0.13 |
| Servidor | Cloudflare Workers, rutas API en TypeScript |
| Datos | Cloudflare D1/SQLite, esquema y migraciones Drizzle |
| Identidad actual | Sign in with ChatGPT, gestionado por Sites |
| Pagos | Código para Wompi Checkout Web y webhook, pendiente de cuenta real |
| Idiomas | Español en `/`; inglés en `/en` y sus subrutas |

Las versiones exactas y dependencias están fijadas en `package-lock.json`.
Mantener el lockfile al instalar; no actualizar dependencias por rutina.

## 2. Mapa de archivos

Todas estas rutas son relativas a `proyecto/`.

| Ruta | Función |
|---|---|
| `components/chomby-home.tsx` | Portada y seis categorías de servicios |
| `components/site-shell.tsx` | Navegación, cambio de idioma y pie |
| `components/site-pages.tsx` | Páginas de servicios, acceso y contenido |
| `components/booking-flow.tsx` | Formulario de solicitud de tres pasos |
| `components/account-panel.tsx` | Reservas del cliente, profesional y administración |
| `components/help-chat.tsx` | Ayuda automática basada en preguntas frecuentes |
| `app/globals.css` | Estilos y adaptación responsive |
| `lib/catalog.ts` | Catálogo, traducciones, localidades, estados y FAQs |
| `lib/booking.ts` | Configuración de rubros y utilidades de fecha |
| `lib/request-validation.ts` | Validación del servidor e intervalos de agenda |
| `app/api/` | Backend HTTP de la aplicación |
| `app/chatgpt-auth.ts` | Lectura de identidad confiable y enlaces de acceso |
| `lib/server.ts` | Autorización administrativa, validación de origen y respuestas |
| `lib/payment.ts` | Firma de cobro y verificación criptográfica de eventos |
| `db/schema.ts` | Tablas: profesionales, reservas y bloqueos de agenda |
| `db/raw.ts` | Acceso a D1 y configuración del runtime |
| `drizzle/0000_groovy_legion.sql` | Migración inicial e impedimento de solapamientos |
| `drizzle/meta/` | Historial y snapshots de migraciones |
| `lib/seo.ts`, `app/robots.txt/`, `app/sitemap.xml/` | Metadatos, indexación y sitemap |
| `public/` | Imágenes, mascota y favicon |
| `worker/index.ts` | Entrada del Worker |
| `vite.config.ts`, `build/sites-vite-plugin.ts` | Construcción y enlaces a recursos |
| `.openai/hosting.json` | Identidad del Site y enlace lógico de la base (`DB`) |
| `tests/` | Pruebas del Worker con base y pagos de prueba |

El `README.md` dentro de `proyecto/` es documentación histórica del starter.
Por ejemplo, allí se describe un esquema vacío, pero Chomby ya tiene sus tablas.
Usar esta guía para conocer el estado actual. Los documentos antiguos de agendas
y SEO en `docs/` también describen fases anteriores; el informe vigente es
`docs/bogota-operational-review.md`.

## 3. Backend incluido

| Método y ruta | Resultado / permiso |
|---|---|
| `GET /api/account` | Identidad actual y condición administrativa |
| `GET /api/bookings` | Reservas del usuario autenticado |
| `POST /api/bookings` | Validar y guardar solicitud; clave de idempotencia |
| `PATCH /api/bookings/:id` | Cancelar solicitud propia o pedir revisión de cancelación |
| `GET /api/professionals` | Perfil propio y solicitudes permitidas por rol |
| `POST /api/professionals` | Solicitud de ingreso profesional, pendiente de revisión |
| `PATCH /api/professionals` | Profesional aprobado ofrece precio y confirma disponibilidad |
| `GET /api/admin` | Administración de perfiles, reservas y estado de configuración |
| `PATCH /api/admin` | Aprobar, rechazar o desactivar un perfil; solo administración |
| `POST /api/checkout` | Obtener checkout firmado para una propuesta vigente y propia |
| `POST /api/wompi` | Recibir y verificar eventos del proveedor de pago |

Los cuerpos JSON y las validaciones exactas están en las rutas y en
`lib/request-validation.ts`. Los tests contienen ejemplos ejecutables con datos
sintéticos. Ninguna petición de cliente debe poder elegir su propio rol,
confirmar su pago, modificar el total cobrado o ver reservas ajenas.

El flujo principal es `requested` → `quoted` → `payment_pending` → `confirmed`.
La base evita cruces de intervalos por profesional. Una oferta reserva el horario
por hasta 24 horas y vence antes del servicio. El hotel considera ingreso/salida;
las recurrencias permitidas contemplan cuatro sesiones semanales.
`cancelled`, `cancel_requested`, `refund_requested` y `paid_attention` distinguen
cancelaciones e incidencias. No hay reembolso automático.

## 4. Instalar, compilar y ejecutar las pruebas

Entorno de referencia: Linux con Node.js 24 y npm; Bash, curl, flock,
GNU timeout y sha256sum. En Windows puede utilizarse WSL con Linux.
El `package.json` permite Node >=22.13, pero la entrega fue verificada con Node 24,
y las pruebas utilizan `node:sqlite`.

Desde la carpeta `proyecto/`:

```bash
npm run install:ci
npm run build
node --test tests/booking.test.mjs tests/payment.test.mjs tests/rendered-html.test.mjs
```

Los tres archivos de pruebas indicados corresponden a las 50 verificaciones de
Chomby. Las pruebas usan un adaptador SQLite aislado y eventos de pago sintéticos;
no requieren las claves reales ni hacen cobros reales. Importan `dist/server`,
por eso se compila antes de ejecutarlas.

Para desarrollo visual en el equipo del desarrollador:

```bash
npm run dev
```

Usar la dirección que imprima Vite. Este comando permite servir la aplicación,
pero NO configura por sí solo inicio de sesión, tablas, cuenta comercial o pagos.
La simulación de D1 está declarada en `vite.config.ts`; hay que aplicar las
migraciones a la base local elegida antes de probar operaciones persistentes.
Este proyecto no tiene `wrangler.jsonc`: no asumir que un comando de despliegue
Wrangler ajeno al proyecto ya cuenta con configuración válida.

La compilación previa pasó. La comprobación TypeScript separada reportó tipos
ambientales de Cloudflare faltantes (`cloudflare:workers`, `Fetcher`,
`D1Database`); hay que generar/incluir los tipos del entorno elegido al preparar
el desarrollo fuera de Sites. No presentar esa comprobación como aprobada.

## 5. Si se continúa en Sites

- El archivo `.openai/hosting.json` identifica el proyecto original. No da acceso
  por sí mismo; compartir un ZIP no concede permisos de edición/publicación.
- El enlace lógico D1 debe ser `DB`. Las migraciones se aplican al publicar por
  el proceso de Sites; no se ejecutan contra producción mediante los tests.
- Las variables se configuran en el entorno de Sites, fuera del código.
- Conservar `sites()` en Vite y la entrada Worker. No crear un Site de reemplazo
  ni publicar sobre otro proyecto por copiar su identificador.
- Los secretos, usuarios y datos reales NO viajan dentro del ZIP.

## 6. Si se traslada a otra infraestructura

El frontend y las reglas de negocio son reutilizables, pero la entrega está
integrada con Sites y Cloudflare. No es un backend independiente de proveedor.

1. Elegir un despliegue compatible con Workers o adaptar el runtime del servidor.
2. Crear/conectar la base D1 real, conservar el enlace `DB` o adaptar `db/raw.ts`.
   El identificador ficticio en `vite.config.ts` es solo para desarrollo.
3. Aplicar las migraciones completas, incluido el trigger de solapamientos.
   No editar migraciones que ya se hayan aplicado a una base existente.
4. Implementar una autenticación confiable en el destino y adaptar
   `app/chatgpt-auth.ts`, las páginas protegidas y las comprobaciones de rol.
   **Nunca confiar en cabeceras `oai-authenticated-user-*` enviadas libremente por
   el visitante.** En Sites esas cabeceras las establece su infraestructura;
   exponer el Worker directamente sin sustituir esa confianza sería inseguro.
5. Cambiar el dominio canónico en `lib/seo.ts` y revisar redirección del pago,
   webhook, origen de las peticiones, rutas de idioma y acceso.
6. Configurar variables en el gestor de secretos del destino y volver a probar
   autorización, base, intervalos, checkout y eventos en esa infraestructura.

## 7. Configuración y pagos

`configuracion.env.example` enumera las variables; NO incluye credenciales.
El servidor lee el entorno de Cloudflare, no un archivo de texto de la entrega.
Copiar el ejemplo a una carpeta no activa los pagos.

- `CHOMBY_ADMIN_EMAILS`: correos permitidos, separados por coma. Deben corresponder
  a identidades autenticadas; no conceder administración al primer usuario.
- `WOMPI_PUBLIC_KEY`: clave pública comercial de producción.
- `WOMPI_INTEGRITY_SECRET`: secreto de firma, solo servidor.
- `WOMPI_EVENTS_SECRET`: secreto de eventos, solo servidor.

El checkout requiere claves de producción en el código actual; no hay un selector
completo sandbox/producción. Para hacer una integración bancaria de prueba,
el desarrollador debe configurar explícitamente los endpoints y claves del
entorno elegido, evitando mezclarlo con datos o usuarios reales.
El webhook es `https://DOMINIO-DE-CHOMBY/api/wompi`; sustituir el dominio por el
real y configurarlo en el comercio. La vuelta al sitio no prueba que se pagó.

La firma del checkout se calcula en el servidor. El evento se verifica y se
consulta la transacción en Wompi. Un pago tardío sin bloqueo de agenda vigente
queda para revisión. Completar conciliación, alertas y pruebas externas antes de
procesar dinero real. Referencias de integración usadas por el proyecto:

- https://docs.wompi.co/en/docs/colombia/widget-checkout-web/
- https://docs.wompi.co/en/docs/colombia/eventos/
- https://docs.wompi.co/en/docs/colombia/transacciones/

## 8. Idiomas, SEO e imágenes

El contenido en ambos idiomas se genera en servidor. Los enlaces recíprocos de
idioma y canónicas están incluidos. `INDEXING_ENABLED` sigue en `false` porque
el lanzamiento comercial no está completo. Cambiarlo solo después de revisar
el dominio, los servicios reales, términos y cobertura; revisar también sitemap.
No se garantiza posicionamiento ni aparición en respuestas de IA.

Las imágenes en `public/` son ilustrativas; no son perfiles de profesionales
contratados. Optimizar formatos/peso y verificar la experiencia en dispositivos
reales antes de lanzar. La revisión visual previa cubrió portada y chat en español;
el navegador de prueba bloqueó la ruta en inglés, que sí pasó las pruebas SSR.

## 9. Integridad de la entrega

El código de `proyecto/` reproduce los archivos versionados del commit indicado
en `PROCEDENCIA.json`, salvo `tsconfig.tsbuildinfo`, que es un caché generado.
Los documentos en la raíz se agregaron para esta entrega; no cambian la web.
`INVENTARIO-SHA256.txt` contiene las huellas de cada archivo incluido.
