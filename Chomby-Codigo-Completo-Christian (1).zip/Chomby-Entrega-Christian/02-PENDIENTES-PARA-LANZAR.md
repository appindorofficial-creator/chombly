# Pendientes antes de lanzar Chomby comercialmente

## Configuración, negocio y conexiones

- Conectar la cuenta comercial real de Wompi y verificar checkout y webhook.
- Definir precios finales en COP; US$10 sigue siendo una referencia provisional.
- Incorporar profesionales reales y verificar identidad, credenciales, especies,
  cobertura y condiciones de participación.
- Conectar/aplicar la base de datos en el entorno definitivo.
- Verificar acceso de clientes y permisos administrativos en ese entorno.
- Definir razón social, canal de soporte, política de datos, plazos de conservación,
  condiciones de servicio, cancelaciones, reembolsos, comisiones y liquidaciones.

## Funciones que NO están terminadas o integradas

- Videollamada integrada: no hay proveedor de video conectado.
- Historia clínica y emisión/firma/entrega de fórmulas médicas: no implementadas.
- Correo, SMS o WhatsApp automáticos: no conectados. El seguimiento es en la cuenta.
- Reembolsos y pagos automáticos a profesionales: no implementados.
- Agenda pública con disponibilidad real en tiempo real: el recorrido actual
  solicita una fecha preferida y necesita una propuesta del profesional.
- Cambiar una fecha sin cancelar: no hay un flujo dedicado de reprogramación;
  las solicitudes sin pagar se cancelan y se crean nuevamente.
- Cupos simultáneos de hotel, guardería o paseos grupales: el bloqueo actual es
  por profesional y evita solapamientos; no modela múltiples habitaciones/cupos.
- Chat con operador humano o IA generativa: el chat actual utiliza FAQs y reglas.
- Inicio de sesión independiente de Sites: requiere adaptación si se migra.
- Integración con aplicaciones móviles iOS/Android: este ZIP es la web; no incluye
  código de una aplicación móvil que no se haya desarrollado en este proyecto.

## Revisiones técnicas pendientes

- Probar la pasarela real en el entorno comercial elegido y la conciliación de
  intentos fallidos, duplicados, pagos tardíos y solicitudes de reembolso.
- Definir cómo vencer/recuperar pagos abandonados; el estado pendiente no es un
  servicio de conciliación automática ni una garantía de notificación.
- Completar tipos de Cloudflare para que el chequeo TypeScript separado pase.
- Probar ambos idiomas en navegador y móvil reales; verificar accesibilidad,
  carga de imágenes, autenticación, recuperación de sesión y errores de red.
- Establecer soporte para datos personales: acceso, corrección, eliminación,
  retención y respaldos. El texto actual de privacidad es explicativo y provisional.
- Activar indexación SEO solo cuando la información de lanzamiento sea real.

Las 50 pruebas existentes son una base de validación del código, no una
certificación de producción ni una prueba de cobro o atención médica real.
