import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
type Props={params:Promise<{slug:string}>};
export async function generateMetadata({params}:Props){return pageMetadata('/agendar/'+(await params).slug,'es')}
export default async function Page({params}:Props){return <RenderPage path={'/agendar/'+(await params).slug} lang="es"/>}
