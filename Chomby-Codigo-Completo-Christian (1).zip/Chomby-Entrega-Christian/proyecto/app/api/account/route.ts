import {identity,respond,admin} from '@/lib/server';
export async function GET(){const u=await identity();return respond({user:u?{name:u.displayName,email:u.email}:null,admin:u?admin(u.email):false})}
