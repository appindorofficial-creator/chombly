import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
type Props={params:Promise<{path?:string[]}>};
export async function generateMetadata({params}:Props){return pageMetadata('/'+((await params).path||[]).join('/'),'en')}
export default async function Page({params}:Props){return <RenderPage path={'/'+((await params).path||[]).join('/')} lang="en"/>}
