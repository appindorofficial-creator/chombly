import {headers} from "next/headers";
import type { Metadata } from "next";
import { INDEXING_ENABLED, SITE_URL, BRAND_DESCRIPTION } from "@/lib/seo";
import "./globals.css";
export const metadata: Metadata = {
 metadataBase:new URL(SITE_URL),
 title:{default:"Chomby | Veterinario online y servicios para mascotas en Colombia",template:"%s | Chomby"},
 description:BRAND_DESCRIPTION,
 robots:{index:INDEXING_ENABLED,follow:true},
 icons:{icon:"/favicon.svg"},
};
export default async function RootLayout({children}:{children:React.ReactNode}){const h=await headers(); return <html lang={h.get("x-chomby-language")==="en"?"en":"es-CO"}><body>{children}</body></html>}
