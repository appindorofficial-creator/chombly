import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
export const metadata=pageMetadata('/mis-reservas','es');
export default function Page(){return <RenderPage path="/mis-reservas" lang="es"/>}
