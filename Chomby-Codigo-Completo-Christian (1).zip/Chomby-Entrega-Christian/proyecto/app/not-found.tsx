import { ContentShell } from "@/components/content-shell";
export default function NotFound(){return <ContentShell><section className="shell information-page"><p className="eyebrow">PÁGINA NO ENCONTRADA</p><h1>Este camino no lleva a un servicio.</h1><p>Vuelve al inicio para explorar los servicios de Chomby.</p><a href="/" className="button">Volver al inicio</a></section></ContentShell>}
