import {RenderPage,pageMetadata} from '@/components/site-pages';
export const metadata=pageMetadata('/','es');
export default function Page(){return <RenderPage path="/" lang="es"/>}
