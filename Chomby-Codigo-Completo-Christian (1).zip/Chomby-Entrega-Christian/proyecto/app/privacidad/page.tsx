import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
export const metadata=pageMetadata('/privacidad','es');
export default function Page(){return <RenderPage path="/privacidad" lang="es"/>}
