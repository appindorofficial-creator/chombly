import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
export const metadata=pageMetadata('/profesionales','es');
export default function Page(){return <RenderPage path="/profesionales" lang="es"/>}
