import { INDEXING_ENABLED, SITE_URL } from "@/lib/seo";
export function GET(){
 // Allow fetching the public HTML so noindex can be read; authentication remains
 // the protection for this private prototype. This is not an access control.
 const body=["User-agent: *","Allow: /", "", "User-agent: OAI-SearchBot","Allow: /", ...(INDEXING_ENABLED?["",`Sitemap: ${SITE_URL}/sitemap.xml`]:[])].join("\n")+"\n";
 return new Response(body,{headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"public, max-age=300"}});
}
