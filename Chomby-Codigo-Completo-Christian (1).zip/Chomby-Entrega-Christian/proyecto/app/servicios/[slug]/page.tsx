import {RenderPage,pageMetadata} from '@/components/site-pages';
type Props={params:Promise<{slug:string}>};
export async function generateMetadata({params}:Props){return pageMetadata('/servicios/'+(await params).slug,'es')}
export default async function Page({params}:Props){return <RenderPage path={'/servicios/'+(await params).slug} lang="es"/>}
