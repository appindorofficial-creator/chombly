import {RenderPage,pageMetadata} from '@/components/site-pages';
export const dynamic='force-dynamic';
export const metadata=pageMetadata('/sobre-chomby','es');
export default function Page(){return <RenderPage path="/sobre-chomby" lang="es"/>}
