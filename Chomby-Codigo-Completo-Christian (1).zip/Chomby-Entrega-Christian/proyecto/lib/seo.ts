import type { Metadata } from "next";
// Enable only after confirming public access, final domain and operational content.
export const INDEXING_ENABLED = false;
export const SITE_URL = "https://chomby-colombia.jrricardo29.chatgpt.site";
export const BRAND_DESCRIPTION = "Chomby es una plataforma en preparación para conectar a personas en Colombia con veterinarios online y servicios para el cuidado de sus animales.";
export const servicePaths = ["veterinario-online-colombia", "peluqueria-canina-y-felina", "paseadores-de-perros", "hotel-para-mascotas", "guarderia-y-cuidadores", "entrenamiento-canino"];
export function metadataFor(title: string, description: string, path: string, lang: "es"|"en"="es"): Metadata {
 const url = new URL(path, SITE_URL).href;
 return { title, description, alternates: { canonical: url, languages: {"es-CO":new URL(path.replace(/^\/en(?=\/|$)/, "")||"/", SITE_URL).href, en:new URL("/en"+((path.replace(/^\/en(?=\/|$)/, "")||"/") === "/" ? "" : path.replace(/^\/en(?=\/|$)/, "")), SITE_URL).href} },
  robots: { index: INDEXING_ENABLED, follow: true },
  openGraph: { type: "website", locale: lang==="en"?"en_US":"es_CO", siteName: "Chomby", title, description, url },
  twitter: { card: "summary", title, description },
 };
}
export const organization = { "@type": "Organization", "@id": `${SITE_URL}/#organization`, name:"Chomby", url:SITE_URL, description:BRAND_DESCRIPTION };
export const website = { "@type":"WebSite", "@id":`${SITE_URL}/#website`, url:SITE_URL, name:"Chomby", inLanguage:"es-CO", description:BRAND_DESCRIPTION, publisher:{"@id":organization["@id"]} };
export function pageGraph(path:string, title:string, description:string, faqs:readonly (readonly string[])[] = [],lang:"es"|"en"="es") {
 const url=new URL(path,SITE_URL).href;
 const graph:Record<string,unknown>[]=[organization,website,{"@type":"WebPage","@id":`${url}#webpage`,url,name:title,description,inLanguage:lang==="en"?"en":"es-CO",isPartOf:{"@id":website["@id"]},about:{"@id":organization["@id"]}}];
 if(path!=="/") graph.push({"@type":"BreadcrumbList","@id":`${url}#breadcrumbs`,itemListElement:[{"@type":"ListItem",position:1,name:lang==="en"?"Home":"Inicio",item:SITE_URL+"/"},{"@type":"ListItem",position:2,name:title,item:url}]});
 if(faqs.length) graph.push({"@type":"FAQPage","@id":`${url}#preguntas`,isPartOf:{"@id":`${url}#webpage`},mainEntity:faqs.map(([q,a])=>({"@type":"Question",name:q,acceptedAnswer:{"@type":"Answer",text:a}}))});
 return {"@context":"https://schema.org","@graph":graph};
}
export function sitemapPaths() { return ["/",...servicePaths.map(s=>`/servicios/${s}`),"/sobre-chomby","/profesionales"]; }
export function jsonLd(value:unknown) { return JSON.stringify(value).replace(/</g,"\\u003c"); }
