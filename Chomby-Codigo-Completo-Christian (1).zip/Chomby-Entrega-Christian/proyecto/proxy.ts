import {NextResponse, type NextRequest} from 'next/server';
export function proxy(request:NextRequest){const headers=new Headers(request.headers);headers.set('x-chomby-language',request.nextUrl.pathname==='/en'||request.nextUrl.pathname.startsWith('/en/')?'en':'es-CO');return NextResponse.next({request:{headers}})}
export const config={matcher:['/((?!api|_next|assets|favicon).*)']};
